from distutils.core import setup

setup(name='cpat-osint',
    version='1.0',
    py_modules=['flask'],
    )